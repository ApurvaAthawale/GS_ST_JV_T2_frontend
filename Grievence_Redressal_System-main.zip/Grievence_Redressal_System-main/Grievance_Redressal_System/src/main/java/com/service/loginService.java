package com.service;

import org.springframework.stereotype.Repository;

@Repository
public interface loginService {
	
	public static int loginValidation(String username,String password, String role) {
		// TODO Auto-generated method stub
		return 0;
	}
}
