package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.entity.hodDB;

public interface hodDBRepo extends JpaRepository<hodDB, String>{

}
